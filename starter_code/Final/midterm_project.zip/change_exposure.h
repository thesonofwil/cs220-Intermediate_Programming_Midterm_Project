// Wilson Tjoeng
// wtjoeng1

#ifndef CHANGE_EXPOSURE_H
#define CHANGE_EXPOSURE_H

#include "ppm_io.h"

void change_exposure(Image *img, float val);

#endif
