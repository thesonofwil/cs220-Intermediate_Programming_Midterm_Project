//Marcelo Morales
//lmoral10

#ifndef SWIRL_H
#define SWIRL_H

#include "ppm_io.h"
#include "math.h"


void swirl (Image * img_input, int center_x, int center_y, int scale);


#endif
