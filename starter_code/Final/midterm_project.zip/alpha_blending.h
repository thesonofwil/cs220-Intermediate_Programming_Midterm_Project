//Wilson Tjoeng, Anire Egbe
//wjtoeng1, aegbe2

#ifndef alpha_blending_H
#define alpha_blending_H

#include "ppm_io.h"

Image *alpha_blending(Image *img1, Image *img2, float alpha);

#endif
