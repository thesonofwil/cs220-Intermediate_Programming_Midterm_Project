//Marcelo Morales
//lmoral10

#ifndef POINTILISM_H
#define POINTILISM_H

#include "ppm_io.h"
#include "math.h"


void pointilism(Image *img);

#endif